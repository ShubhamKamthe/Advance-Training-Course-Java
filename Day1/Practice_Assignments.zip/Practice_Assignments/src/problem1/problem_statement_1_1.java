//1.1Write a program to list all, even numbers less than or equal to the number n. Take the value of n as input from the user.

package problem1;

import java.util.Scanner;

public class problem_statement_1_1 {

	private static Scanner scan;

	public static void main(String args[]) {

		  scan = new Scanner(System.in);
		  System.out.println("Enter the n value : ");
		  
		  int n = scan.nextInt();

		  for (int i = 1; i <= n; i++) {

		   if (i % 2 == 0) {

		  System.out.print(i + " ");

		   }

		   }

		  }

}
