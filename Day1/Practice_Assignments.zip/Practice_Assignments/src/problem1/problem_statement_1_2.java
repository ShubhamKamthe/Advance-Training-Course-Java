/*
 1.2 Define a class Rectangle with its length and breadth. Follow the below steps,
 a.Provide appropriate constructor(s), 
 which gives facility of constructing Rectangle object with default values of length and breadth as 0 
 or passing value of length and breadth externally to constructor.
 b.Provide appropriate accessor & mutator methods to Rectangle class.
 c.Provide methods to calculate area & to display all information of Rectangle.
 d.Design different classTestRectangle class in a separate source file, which will contain main method.  
 From   this  main   method,  
 create  5  Rectangle  objects  by   taking  all   necessary information from the user 
 and calculate respective area of rectangle objects and display it.
 */

package problem1;

import java.util.Scanner;

class problem_statement_1_2 {
    int length; 
    int breadth; 
    int area;
	private Scanner in; 
   
    public problem_statement_1_2()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) {
    	problem_statement_1_2 obj1 = new problem_statement_1_2();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("****************************");
        problem_statement_1_2 obj2 = new problem_statement_1_2();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("****************************");
        problem_statement_1_2 obj3 = new problem_statement_1_2();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("****************************");
        problem_statement_1_2 obj4 = new problem_statement_1_2();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("****************************");
        problem_statement_1_2 obj5 = new problem_statement_1_2();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}
