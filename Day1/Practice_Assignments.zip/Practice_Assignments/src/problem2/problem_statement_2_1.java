/*
 2.1Write a program that takes a String through Command Line argument and display the length of the string. 
 Also display  the string into  uppercase and  check whether it is a  palindrome  or not.  
 */
package problem2;


import java.util.Scanner;

class problem_statement_2_1
{
   public static void main(String args[])
   {
      String str, rev = "";
      Scanner sc = new Scanner(System.in);
 
      System.out.println("Enter a string:");
      str = sc.nextLine();
 
      int length = str.length();
 
      for ( int i = length - 1; i >= 0; i-- )
         rev = rev + str.charAt(i);
 
      if (str.equals(rev))
         System.out.println(str+" is a palindrome");
      else
         System.out.println(str+" is not a palindrome");
 
   }
}