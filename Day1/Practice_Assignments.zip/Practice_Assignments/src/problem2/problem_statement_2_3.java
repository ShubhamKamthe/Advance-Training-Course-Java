/*
 2.3Write a program that allows you  to  create an integer array of  18  elements with  the following 
 values: int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0}. 
 Perform the following computations,
  a.Compute the sum of elements from index 0 to 14 and stores it at element 15
  b.Compute the average of all numbers and stores it at element 16 
  c.Identifies the smallest value from the array and stores it at element 17 
 */

package problem2;
 

	public class problem_statement_2_3 {  
	    public static void main(String[] args) {  
	        //Initialize array  
	        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
	        int sum = 0;
	        
	        //Loop through the array to calculate sum of elements  
	        for (int i = 0; i < arr.length; i++) {  
	           sum = sum + arr[i];  
	        }  
	        System.out.println("Sum of all the elements of an array: " + sum);


	        
	    }  
	}  